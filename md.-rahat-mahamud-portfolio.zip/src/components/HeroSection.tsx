import React, { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import { Download, ArrowRight, Github, Linkedin, Mail } from 'lucide-react';
import { Link } from 'react-router-dom';
import { usePortfolio } from '../context/PortfolioContext';

export default function HeroSection() {
  const { settings } = usePortfolio();
  const containerRef = useRef<HTMLDivElement>(null);

  // Mouse movement values
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  // Smooth springs for tilt
  const mouseXSpring = useSpring(x);
  const mouseYSpring = useSpring(y);

  // Tilt transforms
  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["10deg", "-10deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-10deg", "10deg"]);

  // Shadow transforms (moves opposite to tilt)
  const shadowX = useTransform(mouseXSpring, [-0.5, 0.5], [20, -20]);
  const shadowY = useTransform(mouseYSpring, [-0.5, 0.5], [20, -20]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;

    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };
  
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 animate-mesh -z-10" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-500/10 blur-[120px] rounded-full animate-pulse" />
      
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-left"
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-emerald-500/10 text-emerald-400 text-sm font-medium mb-6 border border-emerald-500/20">
              Available for new opportunities
            </span>
            <h1 className="text-4xl md:text-6xl font-display font-bold mb-4 tracking-tight leading-tight">
              Hi, I am <span className="text-gradient">{settings.name}</span>
            </h1>
            <p className="text-xl text-slate-400 font-medium mb-2">
              {settings.title}
            </p>
            <p className="text-base text-slate-500 max-w-lg mb-10">
              {settings.bio}
            </p>

            <div className="flex flex-wrap items-center gap-4 mb-12">
              <Link to="/projects" className="glass-button bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/20">
                View Projects <ArrowRight size={18} />
              </Link>
              <button className="glass-button">
                Download CV <Download size={18} />
              </button>
            </div>

            <div className="flex items-center gap-6 text-slate-400">
              <a href="https://github.com/rahat300809/" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">
                <Github size={24} />
              </a>
              <a href="https://www.linkedin.com/in/rahat300809/" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">
                <Linkedin size={24} />
              </a>
              <a href="mailto:rahat3008096081@gmail.com" className="hover:text-white transition-colors">
                <Mail size={24} />
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9, x: 30 }}
            animate={{ opacity: 1, scale: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative hidden lg:block perspective-1000"
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            ref={containerRef}
          >
            <motion.div
              style={{
                rotateX,
                rotateY,
                transformStyle: "preserve-3d",
              }}
              className="relative z-10 w-full max-w-md mx-auto aspect-[4/5] rounded-[2rem] overflow-hidden glass border-white/10 shadow-2xl transition-shadow duration-300"
            >
              <img
                src={settings.profileImage}
                alt={settings.name}
                className="w-full h-full object-cover transition-all duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent" />
            </motion.div>
            
            {/* Dynamic Background Shadow */}
            <motion.div 
              style={{
                x: shadowX,
                y: shadowY,
                scale: 0.95,
              }}
              className="absolute inset-0 bg-emerald-500/20 blur-[60px] rounded-[2rem] -z-10"
            />

            {/* Decorative elements */}
            <div className="absolute -top-6 -right-6 w-32 h-32 bg-emerald-500/20 blur-3xl rounded-full -z-10" />
            <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-cyan-500/20 blur-3xl rounded-full -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
