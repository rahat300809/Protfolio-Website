import React from 'react';
import { motion } from 'motion/react';
import { User, GraduationCap, MapPin, Calendar, Briefcase } from 'lucide-react';

export default function AboutSection() {
  return (
    <section id="about" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <h2 className="text-4xl font-display font-bold mb-6">About <span className="text-gradient">Me</span></h2>
              <p className="text-slate-400 text-lg leading-relaxed">
                I am a passionate Computer Science and Engineering student at Daffodil International University, specializing in IoT and Embedded Systems. My journey in technology is driven by a desire to bridge the gap between hardware and software to create impactful real-world solutions.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="glass-card p-6 flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl glass flex items-center justify-center text-emerald-400 shrink-0">
                  <GraduationCap size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-white">Education</h4>
                  <p className="text-sm text-slate-500">B.Sc. in CSE, DIU</p>
                </div>
              </div>
              <div className="glass-card p-6 flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl glass flex items-center justify-center text-cyan-400 shrink-0">
                  <Briefcase size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-white">Focus</h4>
                  <p className="text-sm text-slate-500">IoT & Embedded Systems</p>
                </div>
              </div>
              <div className="glass-card p-6 flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl glass flex items-center justify-center text-purple-400 shrink-0">
                  <MapPin size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-white">Location</h4>
                  <p className="text-sm text-slate-500">Dhaka, Bangladesh</p>
                </div>
              </div>
              <div className="glass-card p-6 flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl glass flex items-center justify-center text-amber-400 shrink-0">
                  <Calendar size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-white">Experience</h4>
                  <p className="text-sm text-slate-500">3+ Years Learning</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-card p-8 md:p-12 relative"
          >
            <div className="absolute -top-4 -left-4 w-12 h-12 glass rounded-xl flex items-center justify-center text-emerald-400">
              <User size={24} />
            </div>
            <h3 className="text-2xl font-bold mb-6">My Mission</h3>
            <p className="text-slate-400 leading-relaxed mb-8">
              My mission is to leverage my skills in embedded systems and AI to develop smart technologies that solve pressing environmental and social challenges. From smart helmets to urban air purification concepts, I believe in the power of innovation to make the world a safer and cleaner place.
            </p>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 rounded-xl bg-white/5 border border-white/10">
                <span className="text-slate-300">Problem Solving</span>
                <span className="text-emerald-400 font-bold">90%</span>
              </div>
              <div className="flex justify-between items-center p-4 rounded-xl bg-white/5 border border-white/10">
                <span className="text-slate-300">Hardware Integration</span>
                <span className="text-cyan-400 font-bold">95%</span>
              </div>
              <div className="flex justify-between items-center p-4 rounded-xl bg-white/5 border border-white/10">
                <span className="text-slate-300">System Design</span>
                <span className="text-purple-400 font-bold">85%</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
