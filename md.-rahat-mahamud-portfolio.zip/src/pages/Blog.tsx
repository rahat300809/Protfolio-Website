import React from 'react';
import { motion } from 'motion/react';
import { blogPosts } from '../data/mockData';
import { Calendar, ArrowRight, BookOpen } from 'lucide-react';

export default function Blog() {
  return (
    <div className="pt-32 pb-20 container mx-auto px-6">
      <div className="mb-16 text-center">
        <h1 className="text-5xl font-display font-bold mb-6">Latest <span className="text-gradient">Articles</span></h1>
        <p className="text-slate-400 max-w-2xl mx-auto">
          Thoughts, tutorials, and insights on IoT, embedded systems, and the future of technology.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {blogPosts.map((post) => (
          <motion.div
            key={post.id}
            whileHover={{ y: -5 }}
            className="glass-card group overflow-hidden flex flex-col md:flex-row"
          >
            <div className="w-full md:w-2/5 aspect-video md:aspect-square overflow-hidden">
              <img
                src={post.thumbnail}
                alt={post.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="p-8 flex-1 flex flex-col">
              <div className="flex items-center gap-3 text-emerald-400 mb-4">
                <Calendar size={16} />
                <span className="text-sm font-medium">{post.date}</span>
              </div>
              <h3 className="text-2xl font-display font-bold mb-4 group-hover:text-emerald-400 transition-colors">{post.title}</h3>
              <p className="text-slate-400 mb-6 flex-1">{post.preview}</p>
              <button className="flex items-center gap-2 text-emerald-400 font-bold hover:gap-4 transition-all">
                Read More <ArrowRight size={20} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
