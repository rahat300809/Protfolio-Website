import React, { useState } from 'react';
import { motion } from 'motion/react';
import HeroSection from '../components/HeroSection';
import AboutSection from '../components/AboutSection';
import ServicesSection from '../components/ServicesSection';
import ProjectCard from '../components/ProjectCard';
import ProjectModal from '../components/ProjectModal';
import Contact from '../components/Contact';
import { projects } from '../data/mockData';
import { Project } from '../types';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const featuredProjects = projects.slice(0, 3);

  return (
    <div className="pb-20">
      <HeroSection />
      
      <AboutSection />

      <ServicesSection />

      <section className="py-24 container mx-auto px-6">
        <div className="flex items-end justify-between mb-12">
          <div>
            <h2 className="text-4xl font-display font-bold mb-4">Featured <span className="text-gradient">Projects</span></h2>
            <p className="text-slate-400 max-w-xl">
              A selection of my recent work in IoT, Embedded Systems, and Web Development.
            </p>
          </div>
          <Link to="/projects" className="hidden md:flex items-center gap-2 text-emerald-400 font-medium hover:gap-4 transition-all">
            View All Projects <ArrowRight size={20} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredProjects.map((project) => (
            <ProjectCard 
              key={project.id} 
              project={project} 
              onClick={setSelectedProject} 
            />
          ))}
        </div>

        <div className="mt-12 text-center md:hidden">
          <Link to="/projects" className="glass-button inline-flex">
            View All Projects <ArrowRight size={18} />
          </Link>
        </div>
      </section>

      <Contact />

      <ProjectModal 
        project={selectedProject} 
        onClose={() => setSelectedProject(null)} 
      />
    </div>
  );
}
