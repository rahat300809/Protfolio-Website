import React, { useState } from 'react';
import { motion } from 'motion/react';
import { projects } from '../data/mockData';
import ProjectCard from '../components/ProjectCard';
import ProjectModal from '../components/ProjectModal';
import { Project } from '../types';
import { Search, Filter } from 'lucide-react';

const categories = ["All", "IoT", "Embedded Systems", "Robotics", "Web Development", "AI", "Mobile"];

export default function Projects() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [filter, setFilter] = useState("All");
  const [search, setSearch] = useState("");

  const filteredProjects = projects.filter(p => {
    const matchesFilter = filter === "All" || p.category.toLowerCase().includes(filter.toLowerCase());
    const matchesSearch = p.title.toLowerCase().includes(search.toLowerCase()) || 
                          p.description.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="pt-32 pb-20 container mx-auto px-6">
      <div className="mb-16 text-center">
        <h1 className="text-5xl font-display font-bold mb-6">My <span className="text-gradient">Projects</span></h1>
        <p className="text-slate-400 max-w-2xl mx-auto">
          Explore my portfolio of projects ranging from hardware prototypes to full-stack software solutions.
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-6 mb-12">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
          <input
            type="text"
            placeholder="Search projects..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full glass rounded-2xl pl-12 pr-4 py-4 focus:outline-none focus:border-emerald-500/50 transition-all"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-6 py-4 rounded-2xl text-sm font-medium whitespace-nowrap transition-all ${
                filter === cat ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30" : "glass text-slate-400 hover:bg-white/5"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <motion.div 
        layout
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
      >
        {filteredProjects.map((project) => (
          <ProjectCard 
            key={project.id} 
            project={project} 
            onClick={setSelectedProject} 
          />
        ))}
      </motion.div>

      {filteredProjects.length === 0 && (
        <div className="py-20 text-center">
          <p className="text-slate-500 text-lg">No projects found matching your criteria.</p>
        </div>
      )}

      <ProjectModal 
        project={selectedProject} 
        onClose={() => setSelectedProject(null)} 
      />
    </div>
  );
}
