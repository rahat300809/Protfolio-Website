import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { researchItems } from '../data/mockData';
import { Research } from '../types';
import { Calendar, ArrowRight, Microscope, X } from 'lucide-react';

export default function ResearchPage() {
  const [selectedResearch, setSelectedResearch] = useState<Research | null>(null);

  return (
    <div className="pt-32 pb-20 container mx-auto px-6">
      <div className="mb-16 text-center">
        <h1 className="text-5xl font-display font-bold mb-6">Research <span className="text-gradient">Lab</span></h1>
        <p className="text-slate-400 max-w-2xl mx-auto">
          Deep dives into emerging technologies, biotechnology, and artificial intelligence.
        </p>
      </div>

      <div className="max-w-4xl mx-auto space-y-12">
        {researchItems.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative flex flex-col md:flex-row gap-8 items-center"
          >
            <div className="w-full md:w-1/2 aspect-video rounded-3xl overflow-hidden glass">
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="w-full md:w-1/2 space-y-4">
              <div className="flex items-center gap-3 text-emerald-400">
                <Calendar size={18} />
                <span className="text-sm font-medium">{item.date}</span>
              </div>
              <h3 className="text-3xl font-display font-bold">{item.title}</h3>
              <p className="text-slate-400 leading-relaxed">{item.description}</p>
              <button
                onClick={() => setSelectedResearch(item)}
                className="flex items-center gap-2 text-emerald-400 font-bold hover:gap-4 transition-all"
              >
                Read Full Details <ArrowRight size={20} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {selectedResearch && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-10">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedResearch(null)}
              className="absolute inset-0 bg-slate-950/80 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-3xl glass rounded-3xl p-8 md:p-12 overflow-y-auto max-h-[90vh]"
            >
              <button
                onClick={() => setSelectedResearch(null)}
                className="absolute top-6 right-6 p-2 rounded-full hover:bg-white/10 text-slate-400 transition-colors"
              >
                <X size={24} />
              </button>
              <div className="flex items-center gap-4 text-emerald-400 mb-6">
                <Microscope size={32} />
                <span className="text-lg font-bold uppercase tracking-widest">Research Case Study</span>
              </div>
              <h2 className="text-4xl font-display font-bold mb-6">{selectedResearch.title}</h2>
              <div className="prose prose-invert max-w-none">
                <p className="text-slate-300 text-lg leading-relaxed whitespace-pre-wrap">
                  {selectedResearch.fullDetails}
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
