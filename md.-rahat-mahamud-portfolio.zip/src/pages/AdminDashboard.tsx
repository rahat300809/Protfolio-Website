import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  LayoutDashboard, 
  Briefcase, 
  GraduationCap, 
  BookOpen, 
  FileText, 
  Settings, 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  MoreVertical,
  ChevronRight,
  LogOut,
  Zap,
  Cpu,
  Upload,
  User
} from 'lucide-react';
import { projects, certificates, researchItems, blogPosts, skillCategories, portfolioSettings } from '../data/mockData';
import { Link } from 'react-router-dom';

import { usePortfolio } from '../context/PortfolioContext';

export default function AdminDashboard() {
  const { settings, updateSettings } = usePortfolio();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [profileImage, setProfileImage] = useState(settings.profileImage);
  const [name, setName] = useState(settings.name);
  const [title, setTitle] = useState(settings.title);
  const [bio, setBio] = useState(settings.bio);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveSettings = () => {
    updateSettings({
      name,
      title,
      bio,
      profileImage
    });
    alert('Settings saved successfully!');
  };

  const stats = [
    { name: 'Total Projects', value: projects.length, icon: Briefcase, color: 'text-emerald-400' },
    { name: 'Certificates', value: certificates.length, icon: GraduationCap, color: 'text-cyan-400' },
    { name: 'Research Papers', value: researchItems.length, icon: BookOpen, color: 'text-purple-400' },
    { name: 'Blog Posts', value: blogPosts.length, icon: FileText, color: 'text-amber-400' },
  ];

  return (
    <div className="min-h-screen bg-slate-950 flex">
      {/* Sidebar */}
      <aside className="w-64 border-r border-white/10 hidden lg:flex flex-col p-6 sticky top-0 h-screen">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-400 to-cyan-400 flex items-center justify-center text-slate-950 font-bold">
            RM
          </div>
          <span className="font-display font-bold text-xl">Admin Panel</span>
        </div>

        <nav className="flex-1 space-y-2">
          {[
            { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard },
            { id: 'projects', name: 'Projects', icon: Briefcase },
            { id: 'skills', name: 'Skills', icon: Cpu },
            { id: 'certificates', name: 'Certificates', icon: GraduationCap },
            { id: 'research', name: 'Research', icon: BookOpen },
            { id: 'blog', name: 'Blog', icon: FileText },
            { id: 'cv', name: 'CV Generator', icon: FileText },
            { id: 'settings', name: 'Settings', icon: Settings },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                activeTab === item.id ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "text-slate-400 hover:bg-white/5"
              }`}
            >
              <item.icon size={18} />
              {item.name}
            </button>
          ))}
        </nav>

        <Link to="/" className="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white transition-all mt-auto">
          <LogOut size={18} />
          Exit Admin
        </Link>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
          <div>
            <h1 className="text-3xl font-display font-bold capitalize">{activeTab}</h1>
            <p className="text-slate-500">Manage your portfolio content and settings.</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
              <input 
                type="text" 
                placeholder="Search..." 
                className="bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-emerald-500/50"
              />
            </div>
            <button className="glass-button py-2 bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
              <Plus size={18} /> Add New
            </button>
          </div>
        </header>

        {activeTab === 'dashboard' && (
          <div className="space-y-10">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat) => (
                <div key={stat.name} className="glass-card p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-10 h-10 rounded-xl glass flex items-center justify-center ${stat.color}`}>
                      <stat.icon size={20} />
                    </div>
                    <span className="text-slate-500 text-xs font-bold uppercase tracking-widest">Stats</span>
                  </div>
                  <p className="text-3xl font-display font-bold mb-1">{stat.value}</p>
                  <p className="text-slate-500 text-sm font-medium">{stat.name}</p>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="glass-card p-8">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold">Recent Projects</h3>
                  <button className="text-emerald-400 text-sm font-bold hover:underline">View All</button>
                </div>
                <div className="space-y-4">
                  {projects.slice(0, 5).map((p) => (
                    <div key={p.id} className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5">
                      <div className="flex items-center gap-4">
                        <img src={p.image} className="w-12 h-12 rounded-lg object-cover" referrerPolicy="no-referrer" />
                        <div>
                          <p className="font-bold text-sm">{p.title}</p>
                          <p className="text-slate-500 text-xs">{p.category}</p>
                        </div>
                      </div>
                      <button className="p-2 text-slate-500 hover:text-white"><MoreVertical size={16} /></button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="glass-card p-8">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold">Quick Actions</h3>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { name: 'Update CV', icon: FileText },
                    { name: 'New Blog', icon: FileText },
                    { name: 'Add Cert', icon: GraduationCap },
                    { name: 'Settings', icon: Settings },
                  ].map((action) => (
                    <button key={action.name} className="flex flex-col items-center justify-center gap-3 p-6 rounded-2xl glass hover:bg-white/10 transition-all group">
                      <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-emerald-500/20 group-hover:text-emerald-400 transition-all">
                        <action.icon size={20} />
                      </div>
                      <span className="text-sm font-medium text-slate-400 group-hover:text-white">{action.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'skills' && (
          <div className="space-y-8">
            {skillCategories.map((cat) => (
              <div key={cat.id} className="glass-card p-8">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold">{cat.category}</h3>
                  <div className="flex gap-2">
                    <button className="p-2 rounded-lg hover:bg-white/5 text-slate-400 hover:text-emerald-400 transition-all">
                      <Edit2 size={16} />
                    </button>
                    <button className="p-2 rounded-lg hover:bg-white/5 text-slate-400 hover:text-rose-400 transition-all">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {cat.skills.map((skill) => (
                    <div key={skill.name} className="p-4 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
                      <div>
                        <p className="font-bold text-sm">{skill.name}</p>
                        <p className="text-emerald-400 text-xs font-bold">{skill.level}%</p>
                      </div>
                      <div className="flex gap-2">
                        <button className="p-1.5 rounded-md hover:bg-white/10 text-slate-500 hover:text-white">
                          <Edit2 size={14} />
                        </button>
                        <button className="p-1.5 rounded-md hover:bg-white/10 text-slate-500 hover:text-rose-400">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                  <button className="p-4 rounded-xl border border-dashed border-white/10 text-slate-500 hover:text-emerald-400 hover:border-emerald-500/50 transition-all flex items-center justify-center gap-2">
                    <Plus size={16} /> Add Skill
                  </button>
                </div>
              </div>
            ))}
            <button className="w-full py-4 rounded-2xl border border-dashed border-white/20 text-slate-400 hover:text-emerald-400 hover:border-emerald-500/50 transition-all flex items-center justify-center gap-2">
              <Plus size={20} /> Create New Skill Category
            </button>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="max-w-4xl space-y-8">
            <div className="glass-card p-8">
              <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                <User size={20} className="text-emerald-400" />
                Profile Settings
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                <div className="space-y-4">
                  <p className="text-sm font-medium text-slate-400">Profile Image</p>
                  <div className="relative group">
                    <div className="w-full aspect-[4/5] rounded-2xl overflow-hidden glass border-white/10">
                      <img 
                        src={profileImage} 
                        alt="Profile Preview" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <label className="cursor-pointer p-3 rounded-full bg-emerald-500 text-slate-950 hover:scale-110 transition-transform">
                          <Upload size={20} />
                          <input 
                            type="file" 
                            className="hidden" 
                            accept="image/*" 
                            onChange={handleImageUpload}
                          />
                        </label>
                      </div>
                    </div>
                    <p className="text-[10px] text-slate-500 mt-2 text-center">Recommended: 800x1000px (4:5 ratio)</p>
                  </div>
                </div>

                <div className="md:col-span-2 space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-400">Full Name</label>
                    <input 
                      type="text" 
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500/50"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-400">Professional Title</label>
                    <input 
                      type="text" 
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500/50"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-400">Short Bio</label>
                    <textarea 
                      rows={4}
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500/50 resize-none"
                    />
                  </div>

                  <div className="flex justify-end">
                    <button 
                      onClick={handleSaveSettings}
                      className="glass-button bg-emerald-500/10 text-emerald-400 border-emerald-500/20 px-8"
                    >
                      Save Changes
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="glass-card p-8">
              <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                <Zap size={20} className="text-cyan-400" />
                System Settings
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5">
                  <div>
                    <p className="font-bold text-sm">Maintenance Mode</p>
                    <p className="text-slate-500 text-xs">Temporarily disable the public site.</p>
                  </div>
                  <div className="w-12 h-6 rounded-full bg-slate-800 relative cursor-pointer">
                    <div className="absolute left-1 top-1 w-4 h-4 rounded-full bg-slate-500" />
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5">
                  <div>
                    <p className="font-bold text-sm">Email Notifications</p>
                    <p className="text-slate-500 text-xs">Receive alerts for new contact messages.</p>
                  </div>
                  <div className="w-12 h-6 rounded-full bg-emerald-500/20 relative cursor-pointer border border-emerald-500/30">
                    <div className="absolute right-1 top-1 w-4 h-4 rounded-full bg-emerald-400" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab !== 'dashboard' && activeTab !== 'skills' && activeTab !== 'settings' && (
          <div className="glass-card p-8 text-center py-20">
            <LayoutDashboard size={48} className="mx-auto text-slate-700 mb-4" />
            <h3 className="text-xl font-bold mb-2">{activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Management</h3>
            <p className="text-slate-500 mb-8">This section is under development in the admin panel.</p>
            <button className="glass-button mx-auto">
              <Plus size={18} /> Add New {activeTab.slice(0, -1)}
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
