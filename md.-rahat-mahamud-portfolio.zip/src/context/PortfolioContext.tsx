import React, { createContext, useContext, useState, useEffect } from 'react';
import { PortfolioSettings } from '../types';
import { portfolioSettings as initialSettings } from '../data/mockData';

interface PortfolioContextType {
  settings: PortfolioSettings;
  updateSettings: (newSettings: Partial<PortfolioSettings>) => void;
}

const PortfolioContext = createContext<PortfolioContextType | undefined>(undefined);

export function PortfolioProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<PortfolioSettings>(() => {
    const saved = localStorage.getItem('portfolio_settings');
    return saved ? JSON.parse(saved) : initialSettings;
  });

  useEffect(() => {
    localStorage.setItem('portfolio_settings', JSON.stringify(settings));
  }, [settings]);

  const updateSettings = (newSettings: Partial<PortfolioSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  return (
    <PortfolioContext.Provider value={{ settings, updateSettings }}>
      {children}
    </PortfolioContext.Provider>
  );
}

export function usePortfolio() {
  const context = useContext(PortfolioContext);
  if (context === undefined) {
    throw new Error('usePortfolio must be used within a PortfolioProvider');
  }
  return context;
}
